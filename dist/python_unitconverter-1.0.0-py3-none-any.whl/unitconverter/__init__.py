# src/converter/__init__.py

"""Do various unit conversions.

Modules exported by this package:

- `converter`: Provide several sample math calculations.
"""